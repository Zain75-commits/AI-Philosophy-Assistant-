import streamlit as st
import openai
from datetime import datetime
import os
from fpdf import FPDF

# Set page config
st.set_page_config(page_title="AI Philosophy Assistant", layout="wide")

# Load OpenAI key from secrets
openai.api_key = st.secrets.get("OPENAI_API_KEY", os.getenv("OPENAI_API_KEY"))

# Session state init
if "history" not in st.session_state:
    st.session_state.history = []

# Title
st.title("🧠 AI Philosophy Assistant (AI PhA)")

# Sidebar - Export & Theme Tag
with st.sidebar:
    st.header("🛠 Options")
    export_format = st.radio("Export as", ["Markdown", "PDF"])
    theme_tag = st.text_input("📝 Tag this session", placeholder="e.g. metaphysics, ethics...")

# Input: philosophical ideas
st.subheader("💭 Enter Your Ideas")
user_input = st.text_area("Describe your philosophical insight, thoughts, or dilemmas", height=150)

# Optional voice input (if supported)
if st.button("🎙️ Use Voice (requires browser support)"):
    st.info("Voice input requires Streamlit with browser mic permission (external integration needed).")

# Generate button
if st.button("✨ Generate Philosophical Concept"):
    if not user_input.strip():
        st.warning("Please enter a philosophical idea.")
    else:
        with st.spinner("Generating original concept..."):
            try:
                prompt = f"""
                You are an AI philosopher. Based on the following idea, generate an original and coherent philosophical concept or argument. 
                Make sure it's authentic, not derivative, and give it a title.

                User input: {user_input}
                """
                response = openai.ChatCompletion.create(
                    model="gpt-4",
                    messages=[{"role": "user", "content": prompt}],
                    temperature=0.8
                )
                ai_idea = response['choices'][0]['message']['content']
                timestamp = datetime.now().strftime("%Y-%m-%d %H:%M")
                st.success("Original idea generated!")
                st.markdown(ai_idea)
                st.session_state.history.append({
                    "timestamp": timestamp,
                    "input": user_input,
                    "output": ai_idea,
                    "tag": theme_tag
                })
            except Exception as e:
                st.error(f"Error: {e}")

# Display history
st.subheader("📜 Idea History")
if st.session_state.history:
    for i, entry in enumerate(reversed(st.session_state.history), 1):
        st.markdown(f"### {i}. 🕒 {entry['timestamp']}  `{entry['tag'] or 'untagged'}`")
        st.markdown(f"**Input:** {entry['input']}")
        st.markdown(f"**Output:** {entry['output']}")

# Export feature
if st.session_state.history:
    export_btn = st.button(f"📤 Export as {export_format}")
    if export_btn:
        if export_format == "Markdown":
            md = "# AI Philosophy Session\n\n"
            for entry in st.session_state.history:
                md += f"## {entry['timestamp']} - {entry['tag'] or 'untagged'}\n"
                md += f"**Input:** {entry['input']}\n\n"
                md += f"**Output:**\n{entry['output']}\n\n"
            st.download_button("Download Markdown", data=md, file_name="philosophy_session.md")
        else:
            pdf = FPDF()
            pdf.set_auto_page_break(auto=True, margin=15)
            pdf.add_page()
            pdf.set_font("Arial", size=12)
            pdf.cell(200, 10, txt="AI Philosophy Session", ln=True, align="C")
            for entry in st.session_state.history:
                pdf.ln(10)
                pdf.set_font("Arial", 'B', 12)
                pdf.cell(200, 10, txt=f"{entry['timestamp']} - {entry['tag'] or 'untagged'}", ln=True)
                pdf.set_font("Arial", '', 12)
                pdf.multi_cell(0, 10, txt=f"Input: {entry['input']}\n\nOutput:\n{entry['output']}")
            pdf_path = "/tmp/philosophy_session.pdf"
            pdf.output(pdf_path)
            with open(pdf_path, "rb") as f:
                st.download_button("Download PDF", f, file_name="philosophy_session.pdf")